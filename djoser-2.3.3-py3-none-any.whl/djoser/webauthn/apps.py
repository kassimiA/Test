from django.apps import AppConfig


class WebauthnConfig(AppConfig):
    name = "djoser.webauthn"
