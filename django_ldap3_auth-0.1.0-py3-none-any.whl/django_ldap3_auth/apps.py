from django.apps import AppConfig


class DjangoLdap3AuthConfig(AppConfig):
    name = 'django_ldap3_auth'
    verbose_name = 'LDAP / Active Directory'
